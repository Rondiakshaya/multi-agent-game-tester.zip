# Multi-Agent Game Tester — POC

Minimal POC repository for the multi-agent game tester assignment.

## Structure
- backend/: FastAPI backend, LangChain planner (optional), Playwright-based executor
- frontend/: Minimal HTML UI to trigger planning and execution
- artifacts/ will be created by the backend during runs

## Quick start
1. Create and activate a virtualenv:
   ```
   python -m venv venv
   source venv/bin/activate
   ```
2. Install requirements:
   ```
   pip install -r backend/requirements.txt
   playwright install
   ```
3. (Optional) set OpenAI key for LangChain planner:
   ```
   export OPENAI_API_KEY="sk-..."
   ```
4. Start backend:
   ```
   uvicorn backend.app:app --reload --port 8000
   ```
5. Open `frontend/index.html` in your browser and use the UI.

Note: Playwright must be installed and browser binaries downloaded (see `playwright install`). If you do not provide an OpenAI key, the planner will use fallback default candidates.