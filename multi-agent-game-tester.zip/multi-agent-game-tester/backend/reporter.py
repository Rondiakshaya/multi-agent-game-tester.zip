from .utils import save_json
from datetime import datetime

def build_report(run_id, candidates, ranked, results, analysis):
    report = {
        "run_id": run_id,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "num_candidates": len(candidates),
        "num_executed": len(results),
        "candidates": candidates,
        "selected_top": ranked,
        "results": results,
        "analysis": analysis
    }
    save_json(report, f"artifacts/{run_id}/report.json")
    return report