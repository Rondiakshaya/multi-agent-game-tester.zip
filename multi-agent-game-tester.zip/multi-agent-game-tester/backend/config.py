from pathlib import Path
import os

BASE_DIR = Path(__file__).parent
ARTIFACTS_DIR = BASE_DIR / "artifacts"
ARTIFACTS_DIR.mkdir(exist_ok=True)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")