from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .planner import generate_candidate_tests
from .ranker import rank_candidates
from .orchestrator import orchestrate_run
from .analyzer import analyze_run
from .reporter import build_report
from .utils import new_run_id, save_json
from pathlib import Path
import json

app = FastAPI(title="Multi-Agent Game Tester POC")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/plan")
async def plan(payload: dict):
    url = payload.get("url", "https://play.ezygamers.com/")
    run_id = new_run_id()
    candidates = generate_candidate_tests(url, run_id=run_id)
    for c in candidates:
        if "target_url" not in c:
            c["target_url"] = url
    save_json(candidates, f"artifacts/{run_id}/candidates.json")
    return {"run_id": run_id, "num_candidates": len(candidates)}

@app.post("/execute")
async def execute(run_id: str, top_k: int = 10):
    cand_path = Path("artifacts") / run_id / "candidates.json"
    if not cand_path.exists():
        return {"error": "run_id not found or plan not executed"}
    with open(cand_path,"r") as f:
        candidates = json.load(f)
    ranked = rank_candidates(candidates, top_k=top_k)
    results = await orchestrate_run(run_id, ranked)
    analysis = analyze_run(run_id, results)
    report = build_report(run_id, candidates, ranked, results, analysis)
    return {"run_id": run_id, "report_path": f"artifacts/{run_id}/report.json", "summary": {"num_executed": len(results)}}

@app.get("/report/{run_id}")
async def get_report(run_id: str):
    p = Path("artifacts") / run_id / "report.json"
    if not p.exists():
        return {"error": "report not found"}
    with open(p,"r", encoding="utf-8") as f:
        return json.load(f)