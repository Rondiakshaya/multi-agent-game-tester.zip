import asyncio
from playwright.async_api import async_playwright
from .utils import artifacts_path_for, save_json
import json

async def run_single_test(run_id, test_idx, candidate):
    artifacts_dir = artifacts_path_for(run_id) / f"test_{test_idx}"
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    result = {
        "title": candidate.get("title"),
        "steps": candidate.get("steps"),
        "expected": candidate.get("expected"),
        "verdict": "UNKNOWN",
        "errors": [],
        "artifacts": {}
    }
    try:
        playwright = await async_playwright().start()
        browser = await playwright.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        console_msgs = []
        page.on("console", lambda msg: console_msgs.append({"type": msg.type, "text": msg.text}))

        network_events = []
        page.on("request", lambda req: network_events.append({"url": req.url, "method": req.method}))
        page.on("response", lambda resp: network_events.append({"url": resp.url, "status": resp.status}))

        url = candidate.get("target_url") or (candidate.get("steps",[])[0] if candidate.get("steps") else None)
        if url and str(url).startswith("http"):
            await page.goto(url, wait_until="networkidle")
        else:
            base = "https://play.ezygamers.com/"
            await page.goto(base, wait_until="networkidle")

        for i, step in enumerate(candidate.get("steps",[])):
            s = step.lower()
            if s.startswith("open"):
                continue
            elif "click" in s or "press" in s or "submit" in s:
                try:
                    await page.click("button")
                except Exception:
                    pass
            elif "enter" in s or "type" in s or "input" in s:
                import re
                m = re.search(r'(\d+)', step)
                txt = m.group(1) if m else "123"
                try:
                    await page.fill("input[type='text'], input[type='number']", txt, timeout=2000)
                    await page.keyboard.press("Enter")
                except Exception:
                    pass
            elif "wait" in s:
                import re, asyncio
                m = re.search(r'(\d+)', s)
                secs = int(m.group(1)) if m else 1
                await page.wait_for_timeout(secs*1000)
            else:
                await page.wait_for_timeout(500)

        screenshot_path = artifacts_dir / "page.png"
        await page.screenshot(path=str(screenshot_path), full_page=True)
        html_path = artifacts_dir / "dom.html"
        content = await page.content()
        with open(html_path, "w", encoding="utf-8") as f:
            f.write(content)

        with open(artifacts_dir / "console.json", "w", encoding="utf-8") as f:
            json.dump(console_msgs, f, indent=2)
        with open(artifacts_dir /"network.json", "w", encoding="utf-8") as f:
            json.dump(network_events, f, indent=2)

        exp_ok = False
        expected = candidate.get("expected","")
        if expected and expected.lower() in content.lower():
            exp_ok = True

        result["verdict"] = "PASS" if exp_ok else "UNDETERMINED"
        result["artifacts"] = {
            "screenshot": str(screenshot_path),
            "dom": str(html_path),
            "console": str(artifacts_dir / "console.json"),
            "network": str(artifacts_dir / "network.json"),
        }
        await context.close()
        await browser.close()
        await playwright.stop()
    except Exception as e:
        result["verdict"] = "ERROR"
        result["errors"].append(str(e))
    save_json(result, artifacts_path_for(run_id) / f"test_{test_idx}" / "result.json")
    return result

async def run_tests_concurrent(run_id, candidates):
    tasks = []
    for idx, cand in enumerate(candidates, start=1):
        tasks.append(run_single_test(run_id, idx, cand))
    results = await asyncio.gather(*tasks)
    return results