def rank_candidates(candidates, top_k=10):
    def score(c):
        s = 0
        txt = (c.get("title","") + " " + " ".join(c.get("steps",[])) + " " + c.get("expected","")).lower()
        if "edge" in txt or "invalid" in txt or "timeout" in txt or "network" in txt:
            s += 50
        s += len(c.get("steps",[]))*5
        s += min(20, len(txt)//20)
        return s
    ranked = sorted(candidates, key=score, reverse=True)
    return ranked[:top_k]