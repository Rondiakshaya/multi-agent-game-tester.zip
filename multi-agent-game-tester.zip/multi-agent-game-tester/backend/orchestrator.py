import asyncio
from .executor import run_tests_concurrent

async def orchestrate_run(run_id, top_candidates):
    results = await run_tests_concurrent(run_id, top_candidates)
    return results