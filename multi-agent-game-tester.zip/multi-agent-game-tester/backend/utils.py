import json
from datetime import datetime
from pathlib import Path
from uuid import uuid4
from .config import ARTIFACTS_DIR

def new_run_id():
    return datetime.utcnow().strftime("%Y%m%dT%H%M%SZ") + "_" + uuid4().hex[:6]

def save_json(obj, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)

def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def artifacts_path_for(run_id):
    p = ARTIFACTS_DIR / run_id
    p.mkdir(parents=True, exist_ok=True)
    return p