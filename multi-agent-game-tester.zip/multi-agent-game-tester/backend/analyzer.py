from .utils import save_json
import copy

def analyze_run(run_id, executor_results):
    analysis = []
    for r in executor_results:
        item = copy.deepcopy(r)
        item["analysis_notes"] = []
        if item["verdict"] == "UNDETERMINED":
            item["analysis_notes"].append("UNDETERMINED: schedule one repeat run to check flakiness")
            item["suggest_repeat"] = True
        elif item["verdict"] == "ERROR":
            item["analysis_notes"].append("Error encountered during execution; check console/network artifacts")
            item["suggest_repeat"] = False
        elif item["verdict"] == "PASS":
            item["analysis_notes"].append("Observed expected text in DOM content")
        else:
            item["analysis_notes"].append("Manual triage recommended")
        analysis.append(item)
    save_json(analysis, f"artifacts/{run_id}/analysis.json")
    return analysis