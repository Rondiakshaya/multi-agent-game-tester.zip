try:
    from langchain import OpenAI, LLMChain
    from langchain.prompts import PromptTemplate
    from .config import OPENAI_API_KEY
    llm = OpenAI(openai_api_key=OPENAI_API_KEY, temperature=0.7, model="gpt-4o-mini")
    HAS_LC = True
except Exception:
    HAS_LC = False

from .utils import save_json
import json, re

PLANNER_PROMPT = """You are a test-case planner for a web number/math puzzle game at {url}.
Produce a JSON array of 20 candidate test cases. Each test case must be an object with:
- title
- steps (array of strings)
- expected
Return only the JSON array.
"""

def default_candidates(url):
    candidates = []
    for i in range(1,21):
        candidates.append({
            "title": f"Candidate {i}: basic numeric input flow",
            "steps": [
                f"Open {url}",
                "Locate the main number input",
                "Enter number 123",
                "Submit"
            ],
            "expected": "Game accepts input and updates score or puzzle state.",
            "target_url": url
        })
    return candidates

def generate_candidate_tests(url, run_id=None):
    if not HAS_LC:
        arr = default_candidates(url)
    else:
        prompt = PromptTemplate(template=PLANNER_PROMPT, input_variables=["url"])
        chain = LLMChain(llm=llm, prompt=prompt)
        res = chain.run(url=url)
        # extract JSON array
        m = re.search(r'(\[.*\])', res, re.S)
        if m:
            try:
                arr = json.loads(m.group(1))
            except Exception:
                arr = default_candidates(url)
        else:
            arr = default_candidates(url)
    if run_id:
        save_json(arr, f"artifacts/{run_id}/candidates.json")
    return arr